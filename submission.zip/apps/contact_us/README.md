# Vue Start

This app is the starting point for all of our 
Vue applications.  To write a new Vue app 
in py4web, clone this application in your apps 
folder, and work on it. 
